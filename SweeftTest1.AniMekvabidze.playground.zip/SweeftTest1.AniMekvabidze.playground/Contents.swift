import UIKit

// Ani Mekvabidze SweeftDigital


//MARK: -  1
//დაწერეთ ფუნქცია, რომელსაც გადაეცემა ტექსტი  და აბრუნებს პალინდრომია თუ არა. (პალინდრომი არის ტექსტი რომელიც ერთნაირად იკითხება ორივე მხრიდან).
//Boolean isPalindrome(String text);

func isPalindrome(someWord: String) -> Bool {
    let reverseString = String(someWord.reversed())
    if(someWord != "" && someWord == reverseString) {
        return true
    } else {
        return false
    }
}
//print(isPalindrome(someWord: "lol"))
//print(isPalindrome(someWord: "acdc"))



//MARK: -  2
//გვაქვს 1,5,10,20 და 50 თეთრიანი მონეტები. დაწერეთ ფუნქცია, რომელსაც გადაეცემა თანხა (თეთრებში) და აბრუნებს მონეტების მინიმალურ რაოდენობას, რომლითაც შეგვიძლია ეს თანხა დავახურდაოთ.
//Int minSplit(Int amount);

func minSplit(money: Int) -> Int {
    
    var amount = 0
    var money = money
    
    if money / 50 != 0 {
        amount += money / 50
        money = money % 50
    }
    if money / 20 != 0 {
        amount += money / 20
        money = money % 20
    }
    if money / 10 != 0 {
        amount += money / 10
        money = money % 10
    }
    if money / 5 != 0 {
        amount += money / 5
        money = money % 5
    }
    if money / 1 != 0 {
        amount += money / 1
        money = money % 1
    }
    
    return amount
    
}
//print(minSplit(money: 621))


//MARK: -  3
//მოცემულია მასივი, რომელიც შედგება მთელი რიცხვებისგან. დაწერეთ ფუნქცია რომელსაც გადაეცემა ეს მასივი და აბრუნებს მინიმალურ მთელ რიცხვს, რომელიც 0-ზე მეტია და ამ მასივში არ შედის.
//Int notContains(Int[] array);

func notContains(array: [Int]) -> Int {
    
    var minInt = 0
    while true {
        minInt += 1
        if array.contains(minInt) {
            continue
        } else {
            break
        }
    }
    return minInt
    
}

let arrayOne = [10, 77, 3, 0, 600]
let arrayTwo = [1, 2, 20, 11, 0]
//print(notContains(array: arrayOne))
//print(notContains(array: arrayTwo))


//MARK: -  4
//მოცემულია String რომელიც შედგება „(„ და „)“ ელემენტებისგან. დაწერეთ ფუნქცია რომელიც აბრუნებს ფრჩხილები არის თუ არა მათემატიკურად სწორად დასმული.
//Boolean isProperly(String sequence);
//მაგ: (()()) სწორი მიმდევრობაა,  ())() არასწორია

func isProperly(sequence: String) -> Bool {
    
    if sequence.count % 2 == 0 {
        
        let mySequence = Array(sequence)
        let myReversedSequence = Array(sequence.reversed())
        
        for i in 0..<sequence.count {
            if mySequence[i] == "(" && myReversedSequence[i] == ")" {
                continue
            } else if mySequence[i] == ")" && myReversedSequence[i] == "(" {
                continue
            } else {
                return false
            }
        }
        
        return true
        
    } else {
        return false
    }
    
}
//print(isProperly(sequence: "(()())"))
//print(isProperly(sequence: "())()"))



//MARK: -  5
//გვაქვს n სართულიანი კიბე, ერთ მოქმედებაში შეგვიძლია ავიდეთ 1 ან 2 საფეხურით. დაწერეთ ფუნქცია რომელიც დაითვლის n სართულზე ასვლის ვარიანტების რაოდენობას.
//Int countVariants(Int stearsCount);

func countVariants(stairsCount: Int) -> Int {

    if stairsCount == 1 || stairsCount == 0 {
        return 1
    } else if stairsCount == 2 {
        return 2
    } else {
        return countVariants(stairsCount: stairsCount - 2) + countVariants(stairsCount: stairsCount - 1)
    }

}
//print(countVariants(stairsCount: 14))


//MARK: -  6
//დაწერეთ საკუთარი მონაცემთა სტრუქტურა, რომელიც საშუალებას მოგვცემს O(1) დროში წავშალოთ ელემენტი.

class myStruct {
    
    private var myArray: [String]
    
    init(myArray: [String]) {
        self.myArray = myArray
    }
    
    func removeElement(index: Int) {
        if myArray.indices.contains(index) {
            myArray.remove(at: index)
            print("Removed")
        } else {
            print("Error: Index Not Found")
        }
    }
    
}

var animals = myStruct(myArray: ["dog", "cat", "hourse", "elephant"])
//animals.removeElement(index: 1)
//animals.removeElement(index: 2)
//animals.removeElement(index: 10)


